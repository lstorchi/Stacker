#!/usr/local/bin/python

try:
    from pyNSGA2 import NSGA2
    __all__ = ['NSGA2']
except:
    __all__ = []
#end
