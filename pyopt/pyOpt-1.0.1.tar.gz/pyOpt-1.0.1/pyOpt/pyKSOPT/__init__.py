#!/usr/local/bin/python

try:
    from pyKSOPT import KSOPT
    __all__ = ['KSOPT']
except:
    __all__ = []
#end
