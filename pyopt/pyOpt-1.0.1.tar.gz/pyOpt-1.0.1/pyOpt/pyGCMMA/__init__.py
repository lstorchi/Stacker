#!/usr/local/bin/python

try:
    from pyGCMMA import GCMMA
    __all__ = ['GCMMA']
except:
    __all__ = []
#end
